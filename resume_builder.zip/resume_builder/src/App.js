import logo from './logo.svg';
import './App.css';
import Head from './components/Header';
import Footer from './components/Footer';
import Main from './components/Main';
import Login from './components/login';
import Contact from './components/contact';
import {BrowserRouter, Route,Routes} from 'react-router-dom'
function App() {
  return (
    <>
    <div className="head">
    
        <BrowserRouter>
        <Head/>
        <Routes>
          <Route path='/' element={<Main/>}/>
          <Route path='/login' element={<Login/>}/>
          <Route path='/contact' element={<Contact/>}/>
          {/* <Route path='/' element={<Home/>}/> */}
        </Routes>
        </BrowserRouter>
        <Footer/>
    </div>
    </>
  );
}

export default App;
