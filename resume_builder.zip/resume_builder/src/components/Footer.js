import React from "react";
import './foot.css'
import {FaTwitter,FaFacebook,FaInstagram} from 'react-icons/fa'
function Footer(){
    return (
        <>
        <footer className='foot'>
            <div className="foot1">
            <div className='div1'>
                <h1 align='center'>About</h1>
                <p>Our Website provides a user interactive Resume/CV
                    builders.
                </p>
            </div>
            <div className='div1'>
            <h1 align='center'>Follow Us</h1>
                <ul>
                    <li>{<FaFacebook/>}</li>
                    <li>{<FaTwitter/>}</li>
                    <li>{<FaInstagram/>}</li>
                </ul>
            </div>
            </div>
        </footer>
        </>
    )
}

export default Footer