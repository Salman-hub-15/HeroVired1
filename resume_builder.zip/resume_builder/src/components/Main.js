import React from "react";
import './main.css';
import Create from './create-resume';
import { useState } from "react"

function Main()
{
    const [isCreate,setCreate]=useState(false);
    const handleCreate=()=>{
        setCreate(true);
    }
    if(isCreate){
        return(
            <Create/>
        )
    }
    return(
        <>
       <p id='p'><h1>Resume Builder</h1></p>
        <div className="Main">
            <div className='main-div'>
            <div className='d1' onClick={()=>{
                handleCreate();
            }}>

            <img src='../pic1.webp'></img>
            </div>
            <div className='d1' onClick={()=>{
                handleCreate();
            }}>
                <img src='../pic2.png'></img>
            </div>
            <div className='d1' onClick={()=>{
                handleCreate();
            }}>
                <img src='../pic3.avif'></img>
            </div>

        </div>
        </div>
        </>
    )
}

export default Main;