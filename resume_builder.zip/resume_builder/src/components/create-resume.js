import React, { useState } from "react";
import './create.css'
import Create1 from './temp'
function Create(){
    const [a,setTemp]=useState(false);
    const handleTemp=()=>{
        setTemp(true);
    }
    if(a){
        return(
            <Create1/>
        )
    }
    return(
        <>
        <div className="mainDiv">
            <div>
            <h1 id='p'>Resume Creation</h1>
            </div>
            <div>
                <form>
                    <table className="tab">
                        <tr>
                   <td><h1>How Long have you been working</h1></td>
                   </tr>
                   <tr>
                  <td><input type='radio' name='a' value='No Experience'></input>No Experience
                  <input type='radio' name='a' value="Less than 3 yrs"></input>Less than 3 yrs
                  <input type='radio' name='a' value='3-5 yrs'></input>3-5 yrs
                  <input type='radio' name='a' value='5-10 yrs'></input>5-10 yrs
                  <input type='radio' name='a' value='10+ yrs'></input>10+ yrs</td>
                    </tr>
                    <tr>
                        <td><h1>Are you a Student?</h1>
                        Yes<input type='radio' name='b' value='Yes'></input>
                        No<input type='radio' name='b' value='No'></input></td>
                    </tr>
                    <tr>
                        <td><h1>Education Level</h1>
                            <select>
                                <option>Select Education</option>
                                <option>Bachelors</option>
                                <option>Masters</option>
                                <option>Doctorate or Ph.D.</option>
                                <option>Secondary School</option>
                                <option>Associates</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><h1>Country of Destination</h1>
                        <input type='text' placeholder="Country"></input></td>
                    </tr>
                    </table>
                    <button className="btn1" onClick={()=>{
                        handleTemp();
                    }}>See Template</button>
                </form>
            </div>

        </div>
        </>
    )
}

export default Create;