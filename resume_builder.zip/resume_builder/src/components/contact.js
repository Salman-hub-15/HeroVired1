import React from "react";
import './contact.css'
function Contact(){
    return(
        <>
        <div className="cont">
            <form>
            <h1 align='center'>Contact</h1>
            <table className="tab">
            <tr>
            <td><label>Username: </label></td>
            <td><input type='text' placeholder="Enter Username"></input></td>
            </tr>
            <br/>
            <tr>
            <td><label>Email: </label></td>
            <td><input type='email' placeholder="Enter Email"></input></td>
            </tr>
            <br/>

            <tr>
            <td>
            <label>Contact No.: </label></td>
           <td><input type='text' placeholder="Enter Contact" minLength={10} maxLength={10}></input></td>
            </tr>
            <tr>
                <td><label>Additional Info:</label></td>
                <p><textarea className="txt"></textarea></p>
            </tr>
           </table>
        <button className="btn">Submit</button>
            </form>
        </div>
        </>
    )
}
export default Contact;