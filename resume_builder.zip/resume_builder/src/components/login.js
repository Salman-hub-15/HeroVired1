import React from "react";
import './log.css'
function Login(){
    return(
        <>
        <div className="log">
            <form>
                <h1 align='center'>Login</h1>
        <table className="tab">
            <tr>
            <td><label>Username: </label></td>
            <td><input type='email' placeholder="Enter Username"></input></td>
            </tr>
            <br/>
            <tr>
            <td>
            <label>Password: </label></td>
           <td><input type='password' placeholder="Enter Password"></input></td>
            </tr>
        </table>
        <button className="btn">Login</button>
        </form>
        </div>
        </>
    )
}

export default Login;