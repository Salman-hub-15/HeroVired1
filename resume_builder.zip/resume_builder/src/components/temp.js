import React from "react";
import './temp.css'
function Create1(){
    return(
        <>
        <div>
        <div className='im'>
        <img src='../pic1.webp'></img>
        </div>

        </div>
        </>
    )
}

export default Create1;