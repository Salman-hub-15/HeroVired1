import java.util.*;

public class EvenOdd {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        while(true){
            System.out.println("Menu based app - Even/Odd Checker");
            System.out.println("Please enter the number: ");
            int n=sc.nextInt();
            if(n%2==0){
                System.out.println("The given number - "+n+" is a EVEN Number");
            }
            else{
                System.out.println("The given number - "+n+" is a ODD Number");
            }
            System.out.print("Do you want to Continue: ");
            String s=sc.next();
            if(s.equals("n")){
                break;
            }
        }

    }
}
