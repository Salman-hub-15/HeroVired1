import java.util.*;
public class Prime {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter any Number: ");
        int num=sc.nextInt();
        if(num==1 || num==0){
            System.out.print("The given number "+num+" is NOT a Prime number");
        }
        else{
            int c=0;
            for(int i=2;i<=(int)Math.sqrt(num);i++){
                if(num%i==0){
                    c++;
                }
            }
            if(c==0){
                System.out.print("The given number "+num+" is a Prime number");
            }
            else{
                System.out.print("The given number "+num+" is NOT a Prime number");
            }
        }
    }
}
