import java.util.*;
public class Pattern1 {
    public static void main(String[] args) {
        for(int i=1;i<=5;i+=2){
            for(int j=0;j<i;j++){
                System.out.print("*");
            }
            System.out.println();
        }
        int k=5-2;
        for(int i=k;i>=1;i-=2){
            for(int j=0;j<i;j++){ 
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
