import java.util.*;
public class Unit {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        while(true){
            System.out.println("Menu based app - Unit conversion for Distance");
            System.out.println("1.CM to M");
            System.out.println("2.M to KM");
            System.out.println("3.KM to M");
            System.out.println("4.M to CM");
            
            System.out.print("Enter your menu - ");
            int n=sc.nextInt();
            if(n==1){
                System.out.print("Please enter the CM value: ");
                int a=sc.nextInt();
                double k=a*0.01;
                System.out.println(a+" CM = "+k+" M");
            }
            else if(n==2){
                System.out.print("Please enter the M value: ");
                int a=sc.nextInt();
                double k=a*0.001;
                System.out.println(a+" M = "+k+" KM");
            }
            else if(n==3){
                System.out.print("Please enter the KM value: ");
                int a=sc.nextInt();
                double k=a*1000;
                System.out.println(a+" KM = "+k+" M");
            }
            else if(n==4){
                System.out.print("Please enter the M value: ");
                int a=sc.nextInt();
                double k=a*100;
                System.out.println(a+" M = "+k+" CM");
            }
            System.out.print("Do you want to Continue: ");
            String s=sc.next();
            if(s.equals("n")){
                break;
            }
        }
    }
}
