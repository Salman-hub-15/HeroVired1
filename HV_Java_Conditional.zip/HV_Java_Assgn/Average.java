import java.util.*;
public class Average {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("num1 = ");
        int num1=sc.nextInt();
        System.out.print("num2 = ");
        int num2=sc.nextInt();
        System.out.print("num3 = ");
        int num3=sc.nextInt();
        int s,l;
        if(num1>num2){
            if(num1>num3){
                l=num1;
            }
            else{
                l=num3;
            }
        }
        else{
            if(num2>num3){
                l=num1;
            }
            else{
                l=num3;
            }
        }

        if(num1<num2){
            if(num1<num3){
                s=num1;
            }
            else{
                s=num3;
            }
        }
        else{
            if(num2<num3){
                s=num1;
            }
            else{
                s=num3;
            }
        }

        int avg=(num1+num2+num3)/3;

        System.out.println("The Smallest Number: "+s);
        System.out.println("The Largest Number: "+l);
        System.out.println("Average of all three numbers: "+avg);
    }
}
