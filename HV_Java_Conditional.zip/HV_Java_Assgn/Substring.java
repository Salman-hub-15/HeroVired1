import java.util.*;
public class Substring {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("stringName: ");
        String s=sc.next();
        System.out.print("Starting index: ");
        int i1=sc.nextInt();
        System.out.print("Ending Index: ");
        int i2=sc.nextInt();
        String str="";
        for(int i=i1;i<=i2;i++){
            str+=s.charAt(i);
        }
        System.out.println("subString of "+s+" from "+i1+" to "+i2+" is: "+str);
    }
}
