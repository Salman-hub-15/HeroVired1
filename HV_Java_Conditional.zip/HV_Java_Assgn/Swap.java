import java.util.*;
public class Swap {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Before Swapping:");
        System.out.print("numA :");
        int numA=sc.nextInt();
        System.out.print("numB :");
        int numB=sc.nextInt();
        int temp=numA;
        numA=numB;
        numB=temp;
        System.out.println("After Swapping:");
        System.out.println("numA: "+numA);
        System.out.println("numB: "+numB);
    }
}
