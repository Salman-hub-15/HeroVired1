import java.util.*;
import java.lang.*;
public class Percentage {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Marks obtained by Student: ");
        double marks=sc.nextInt();
        // System.out.println();
        System.out.print("Total Marks: ");
        double total=sc.nextInt();
        double per=(marks/total)*100;
        float gpa=0;
        String grade="";
        if(per>=0 && per<=59){
            grade="F";
            gpa=0;
        }
        else if(per>=60 && per<=69){
            grade="D";
            gpa=1;
        }
        else if(per>=70 && per<=79){
            grade="C";
            gpa=2;
        }
        else if(per>=80 && per<=89){
            grade="B";
            gpa=3;
        }
        else if(per>=90 && per<=100){
            grade="A";
            gpa=4;
        }

        System.out.println("Percentage: "+String.format("%.2f", per)+" %");
        System.out.println("Grade "+grade+",GPA = "+gpa);
    }
}
